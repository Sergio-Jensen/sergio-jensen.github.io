#==========================================================================
## Induced-Sequential-Sampling (ISS) algorithm
#==========================================================================
norm.graph <- function(A, directed = FALSE){
  if(inherits(A, "igraph")){
    if(!requireNamespace("igraph", quietly = TRUE)){
      stop("Package 'igraph' is required to convert an igraph object.")
    }
    A <- igraph::as_adjacency_matrix(A, sparse = FALSE)
  }else{
    A <- as.matrix(A)
  }
  A <- (A != 0)
  diag(A) <- FALSE
  if(!directed){
    A <- A | t(A)
    diag(A) <- FALSE
    }
  return(A)
}
g.dens <- function(G, directed = FALSE){
  n <- nrow(G)
  if(n <= 1){return(0)}
  if(directed){
    return(sum(G)/(n*(n - 1)))
  }else{
    return(sum(G[upper.tri(G)])/choose(n, 2))
  }
}
iss.log.sum <- function(x){
  finite <- is.finite(x)
  if(!any(finite)){return(-Inf)}
  m <- max(x[finite])
  m + log(sum(exp(x[finite] - m)))
}
iss.log.mean <- function(log_w){
  exp(iss.log.sum(log_w) - log(length(log_w)))
}
iss.weight.diagnostics <- function(weights){
  finite <- is.finite(weights)
  w <- weights[finite]
  n <- length(weights)
  finite_n <- length(w)
  zero_n <- sum(w == 0)
  total <- sum(w)
  sum_w2 <- sum(w^2)
  mean_w <- if(finite_n > 0){mean(w)}else{NA_real_}
  sd_w <- if(finite_n > 1){stats::sd(w)}else{NA_real_}
  ess <- if(is.finite(total) && total > 0 && is.finite(sum_w2) && sum_w2 > 0){
    total^2/sum_w2
  }else{0}
  list(
    n = n,
    finite = finite_n,
    zero_count = zero_n,
    zero_rate = if(finite_n > 0){zero_n/finite_n}else{NA_real_},
    positive_rate = if(finite_n > 0){mean(w > 0)}else{NA_real_},
    ess = ess,
    ess_ratio = if(finite_n > 0){ess/finite_n}else{NA_real_},
    cv_weight = if(is.finite(mean_w) && mean_w > 0 && is.finite(sd_w)){sd_w/mean_w}else{NA_real_},
    max_weight = if(finite_n > 0){max(w)}else{NA_real_},
    max_weight_share = if(is.finite(total) && total > 0){max(w)/total}else{NA_real_}
  )
}
iss.log.weight.diagnostics <- function(log_weights){
  finite <- is.finite(log_weights)
  if(!any(finite)){
    return(iss.weight.diagnostics(rep(0, length(log_weights))))
  }
  m <- max(log_weights[finite])
  weights <- exp(log_weights - m)
  weights[!is.finite(weights)] <- 0
  iss.weight.diagnostics(weights)
}
iss.wald.ci <- function(estimate, se, level = 0.95){
  if(!is.finite(estimate) || !is.finite(se) || se < 0){return(c(NA_real_, NA_real_))}
  z <- stats::qnorm(1 - (1 - level)/2)
  estimate + c(-1, 1) * z * se
}
iss.log.wald.ci <- function(estimate, se, level = 0.95){
  if(!is.finite(estimate) || estimate <= 0 || !is.finite(se) || se < 0){
    return(c(NA_real_, NA_real_))
  }
  z <- stats::qnorm(1 - (1 - level)/2)
  exp(log(estimate) + c(-1, 1) * z * se/estimate)
}
iss.rare.weight.case <- function(diagnostics, success_rate = NULL,
                                 ess_ratio_threshold = 0.1,
                                 positive_rate_threshold = 0.1,
                                 max_weight_share_threshold = 0.1){
  rare <- FALSE
  if(!is.null(success_rate) && is.finite(success_rate)){
    rare <- rare || success_rate < positive_rate_threshold
  }
  if(!is.null(diagnostics)){
    rare <- rare ||
      (is.finite(diagnostics$ess_ratio) && diagnostics$ess_ratio < ess_ratio_threshold) ||
      (is.finite(diagnostics$positive_rate) && diagnostics$positive_rate < positive_rate_threshold) ||
      (is.finite(diagnostics$max_weight_share) &&
         diagnostics$max_weight_share > max_weight_share_threshold)
  }
  rare
}
iss.bootstrap.mean.ci <- function(weights = NULL, log_weights = NULL, scale = 1,
                                  B_boot = 1000, level = 0.95, seed = NULL,
                                  verbose = T){
  if(!is.null(weights)){
    n <- length(weights)
  }else if(!is.null(log_weights)){
    n <- length(log_weights)
  }else{
    stop("Either weights or log_weights must be supplied.")
  }
  if(n < 1 || B_boot < 1){return(c(NA_real_, NA_real_))}
  if(!is.null(seed)){set.seed(seed)}
  estimates <- numeric(B_boot)
  for(b in seq_len(B_boot)){
    idx <- sample.int(n, n, replace = TRUE)
    estimates[b] <- if(!is.null(weights)){
      mean(weights[idx])/scale
    }else{
      iss.log.mean(log_weights[idx])/scale
    }
    if(verbose && B_boot >= 10 && b %% max(1, floor(B_boot/10)) == 0){
      cat("Finished", b, "of", B_boot, "Bootstrap samples\n")
    }
  }
  stats::quantile(estimates, probs = c((1 - level)/2, 1 - (1 - level)/2),
                  na.rm = TRUE, names = FALSE, type = 7)
}
mot.order <- function(H, graph_density, directed = FALSE, eps = 1e-12){
  k <- nrow(H)
  p <- min(max(graph_density, eps), 1 - eps)
  edge_w <- -log(p)
  nonedge_w <- -log(1 - p)
  pair_weight <- function(has_edge){
    if(has_edge){edge_w}else{nonedge_w}
  }
  global_score <- numeric(k)
  for(u in seq_len(k)){
    others <- setdiff(seq_len(k), u)
    if(directed){
      global_score[u] <- sum(vapply(others, function(v){
        pair_weight(H[u, v]) + pair_weight(H[v, u])
      }, numeric(1)))
    }else{
      global_score[u] <- sum(vapply(others, function(v){
        pair_weight(H[u, v])
      }, numeric(1)))
    }
  }
  first <- which.max(global_score)
  order <- first
  remaining <- setdiff(seq_len(k), first)
  while (length(remaining) > 0){
    scores <- vapply(remaining, function(u){
      imposed <- sum(vapply(order, function(s){
        if(directed){
          pair_weight(H[u, s]) + pair_weight(H[s, u])
        }else{
          pair_weight(H[u, s])
        }
      }, numeric(1)))
      imposed + 1e-9 * global_score[u]
    }, numeric(1))
    next_node <- remaining[which.max(scores)]
    order <- c(order, next_node)
    remaining <- setdiff(remaining, next_node)
  }
  return(order)
}
validate.motif.order <- function(order, H, name = "order"){
  k <- nrow(H)
  if(!is.numeric(order) && !is.integer(order)){
    stop(name, " must be a numeric permutation of motif node indices.")
  }
  if(length(order) != k || !setequal(order, seq_len(k))){
    stop(name, " must be a permutation of motif node indices.")
  }
  as.integer(order)
}
resolve.iss.order <- function(H, density, directed = FALSE, order = NULL,
                              order_method = c("mot.order", "reverse", "random")){
  if(!is.null(order)){
    return(validate.motif.order(order, H, name = "order"))
  }
  order_method <- match.arg(order_method)
  base_order <- mot.order(H, density, directed = directed)
  if(order_method == "reverse"){
    return(rev(base_order))
  }
  if(order_method == "random"){
    return(sample(seq_len(nrow(H))))
  }
  base_order
}
aut.morph <- function(H, directed = FALSE){
  H <- norm.graph(H, directed = directed)
  count <- 0L
  k <- nrow(H)
  visit <- function(prefix, remaining){
    if(length(remaining) == 0){
      P <- H[prefix, prefix, drop = FALSE]
      if(identical(P, H)){
        count <<- count + 1L
      }
      return(invisible(NULL))
    }
    for(v in remaining){
      visit(c(prefix, v), setdiff(remaining, v))
    }
    invisible(NULL)
  }
  visit(integer(0), seq_len(k))
  count
}
bitsets <- function(G){
  n <- nrow(G)
  nonG <- !G
  diag(nonG) <- FALSE
  return(list(adj = G, non_adj = nonG, all = rep(TRUE, n)))
}
get.cand <- function(H, order, step, mapping, used, masks, directed = FALSE){
  subgraph_node <- order[step]
  candidates <- masks$all & !used
  if(step == 1){return(which(candidates))}
  for(prev_step in seq_len(step - 1)){
    prev_subgraph <- order[prev_step]
    prev_graph <- mapping[prev_step]
    if(directed){
      if(H[subgraph_node, prev_subgraph]){
        candidates <- candidates & masks$adj[, prev_graph]
      }else{
        candidates <- candidates & masks$non_adj[, prev_graph]
      }
      if(H[prev_subgraph, subgraph_node]){
        candidates <- candidates & masks$adj[prev_graph, ]
      }else{
        candidates <- candidates & masks$non_adj[prev_graph, ]
      }
    }else{
      if(H[subgraph_node, prev_subgraph]){
        candidates <- candidates & masks$adj[, prev_graph]
      }else{
        candidates <- candidates & masks$non_adj[, prev_graph]
      }
    }
    if(!any(candidates)){
      return(integer(0))
    }
  }
  which(candidates)
}
sample.iss <- function(H, order, masks, directed = FALSE){
  n <- nrow(masks$adj)
  k <- nrow(H)
  mapping <- integer(k)
  used <- rep(FALSE, n)
  weight <- 1
  for(step in seq_len(k)){
    candidates <- get.cand(
      H = H,
      order = order,
      step = step,
      mapping = mapping,
      used = used,
      masks = masks,
      directed = directed
    )
    candidate_count <- length(candidates)
    if(candidate_count == 0){
      return(list(weight = 0, mapping = integer(0), success = FALSE))
    }
    chosen <- if(candidate_count == 1){candidates}else{sample(candidates, 1)}
    mapping[step] <- chosen
    used[chosen] <- TRUE
    weight <- weight * candidate_count
  }
  full_mapping <- integer(k)
  full_mapping[order] <- mapping
  return(list(weight = weight, mapping = full_mapping, success = TRUE))
}
est.subgraph <- function(G, H, B = 10000, directed = FALSE, seed = NULL, order = NULL,
                         order_method = c("mot.order", "reverse", "random"),
                         keep_mappings = FALSE, verbose = TRUE, aut_count = NULL,
                         bootstrap_ci = FALSE, bootstrap_B = 1000, verbose.boot = F,
                         bootstrap_seed = NULL){
  if(!is.null(seed)){set.seed(seed)}
  G <- norm.graph(G, directed = directed)
  H <- norm.graph(H, directed = directed)
  if(nrow(G) != ncol(G)){stop("G must be a square adjacency matrix.")}
  if(nrow(H) != ncol(H)){stop("H must be a square subgraph adjacency matrix.")}
  if(nrow(H) > nrow(G)){stop("The subgraph cannot have more nodes than the graph.")}
  density <- g.dens(G, directed = directed)
  resolved_order_method <- if(is.null(order)){
    match.arg(order_method)
  }else{
    "given"
  }
  order <- resolve.iss.order(
    H = H,
    density = density,
    directed = directed,
    order = order,
    order_method = if(resolved_order_method == "given") "mot.order" else resolved_order_method
  )
  masks <- bitsets(G)
  weights <- numeric(B)
  successes <- logical(B)
  mappings <- if(keep_mappings){vector("list", B)}else{NULL}
  for(b in seq_len(B)){
    draw <- sample.iss(H, order, masks, directed = directed)
    weights[b] <- draw$weight
    successes[b] <- draw$success
    if(keep_mappings && draw$success){
      mappings[[b]] <- draw$mapping
    }
    if(verbose && B >= 10 && b %% max(1, floor(B/10)) == 0){
      cat("Finished", b, "of", B, "samples\n")
    }
  }
  labeled_estimate <- mean(weights)
  labeled_se <- if(B > 1){stats::sd(weights)/sqrt(B)}else{NA_real_}
  if(is.null(aut_count)){aut_count <- aut.morph(H, directed = directed)}
  unlabeled_estimate <- labeled_estimate/aut_count
  unlabeled_se <- labeled_se/aut_count
  labeled_wald_ci_95 <- iss.wald.ci(labeled_estimate, labeled_se)
  unlabeled_wald_ci_95 <- iss.wald.ci(unlabeled_estimate, unlabeled_se)
  labeled_log_wald_ci_95 <- iss.log.wald.ci(labeled_estimate, labeled_se)
  unlabeled_log_wald_ci_95 <- iss.log.wald.ci(unlabeled_estimate, unlabeled_se)
  diagnostics <- iss.weight.diagnostics(weights)
  bootstrap <- NULL
  if(isTRUE(bootstrap_ci)){
    bootstrap <- list(
      labeled_ci_95 = iss.bootstrap.mean.ci(
        weights = weights,
        scale = 1,
        B_boot = bootstrap_B,
        seed = bootstrap_seed,
        verbose = verbose.boot
      ),
      unlabeled_ci_95 = iss.bootstrap.mean.ci(
        weights = weights,
        scale = aut_count,
        B_boot = bootstrap_B,
        seed = if(is.null(bootstrap_seed)) NULL else bootstrap_seed + 1L,
        verbose = verbose.boot
      ),
      B = bootstrap_B,
      method = "nonparametric bootstrap"
    )
  }
  result <- list(B = B,
    directed = directed,
    graph_nodes = nrow(G),
    subgraph_nodes = nrow(H),
    graph_density = density,
    subgraph_order = order,
    order_method = resolved_order_method,
    aut.morph = aut_count,
    successes = sum(successes),
    success_rate = mean(successes),
    labeled_estimate = labeled_estimate,
    labeled_se = labeled_se,
    labeled_ci_95 = labeled_wald_ci_95,
    labeled_wald_ci_95 = labeled_wald_ci_95,
    labeled_log_wald_ci_95 = labeled_log_wald_ci_95,
    unlabeled_estimate = unlabeled_estimate,
    unlabeled_se = unlabeled_se,
    unlabeled_ci_95 = unlabeled_wald_ci_95,
    unlabeled_wald_ci_95 = unlabeled_wald_ci_95,
    unlabeled_log_wald_ci_95 = unlabeled_log_wald_ci_95,
    ci_method = "Wald",
    supplemental_ci_method = "log-scale Wald",
    weight_diagnostics = diagnostics,
    bootstrap_ci = bootstrap,
    weights = weights)
  if(keep_mappings){result$mappings <- mappings}
  class(result) <- "est.subgraph"
  return(result)
}

print.est.subgraph <- function(x, ...){
  cat("Induced-Sequential-Sampling estimate\n")
  cat("  graph nodes:      ", x$graph_nodes, "\n", sep = "")
  cat("  subgraph nodes:      ", x$subgraph_nodes, "\n", sep = "")
  cat("  samples:          ", x$B, "\n", sep = "")
  cat("  success rate:     ", signif(x$success_rate, 4), "\n", sep = "")
  cat("  graph density:    ", signif(x$graph_density, 4), "\n", sep = "")
  cat("  subgraph order:      ", paste(x$subgraph_order, collapse = " -> "), "\n", sep = "")
  cat("  order method:     ", x$order_method, "\n", sep = "")
  cat("  automorphisms:    ", x$aut.morph, "\n", sep = "")
  cat("  labeled estimate: ", signif(x$labeled_estimate, 6),
      " (SE ", signif(x$labeled_se, 4), ")\n", sep = "")
  cat("  labeled Wald 95% CI: [", signif(x$labeled_wald_ci_95[1], 6),
      ", ", signif(x$labeled_wald_ci_95[2], 6), "]\n", sep = "")
  cat("  unlabeled count:  ", signif(x$unlabeled_estimate, 6),
      " (SE ", signif(x$unlabeled_se, 4), ")\n", sep = "")
  cat("  unlabeled Wald 95% CI: [", signif(x$unlabeled_wald_ci_95[1], 6),
      ", ", signif(x$unlabeled_wald_ci_95[2], 6), "]\n", sep = "")
  if(!is.null(x$weight_diagnostics)){
    cat("  ESS ratio:        ", signif(x$weight_diagnostics$ess_ratio, 4), "\n", sep = "")
    cat("  max weight share: ", signif(x$weight_diagnostics$max_weight_share, 4), "\n", sep = "")
  }
  if(iss.rare.weight.case(x$weight_diagnostics, success_rate = x$success_rate) &&
      all(is.finite(x$unlabeled_log_wald_ci_95))){
    cat("  supplemental log-Wald unlabeled 95% CI: [",
        signif(x$unlabeled_log_wald_ci_95[1], 6), ", ",
        signif(x$unlabeled_log_wald_ci_95[2], 6), "]\n", sep = "")
  }
  if(!is.null(x$bootstrap_ci)){
    cat("  bootstrap unlabeled 95% CI: [", signif(x$bootstrap_ci$unlabeled_ci_95[1], 6),
        ", ", signif(x$bootstrap_ci$unlabeled_ci_95[2], 6), "]\n", sep = "")
  }
  invisible(x)
}
iss.order.sensitivity <- function(G, H, B = 10000, directed = FALSE, seed = NULL,
                                  order = NULL,
                                  orders = c("mot.order", "reverse"),
                                  random_orders = 0,
                                  aut_count = NULL,
                                  verbose = FALSE,
                                  bootstrap_ci = FALSE,
                                  bootstrap_B = 1000,
                                  verbose.boot = FALSE,
                                  keep_results = TRUE,
                                  verbose.sens = T){
  if(!is.null(seed)){set.seed(seed)}
  G <- norm.graph(G, directed = directed)
  H <- norm.graph(H, directed = directed)
  density <- g.dens(G, directed = directed)
  if(is.null(aut_count)){
    aut_count <- aut.morph(H, directed = directed)
  }
  order_list <- list()
  add_order <- function(name, value){
    order_list[[name]] <<- validate.motif.order(value, H, name = name)
    invisible(NULL)
  }
  base_order <- if(is.null(order)){
    mot.order(H, density, directed = directed)
  }else{
    validate.motif.order(order, H, name = "order")
  }
  if(length(orders) > 0){
    for(spec in orders){
      if(spec %in% c("mot.order", "default", "rarity")){
        add_order("mot.order", base_order)
      }else if(spec == "reverse"){
        add_order("reverse", rev(base_order))
      }else if(spec == "given"){
        add_order("given", base_order)
      }else{
        stop("Unknown ISS order sensitivity option: ", spec)
      }
    }
  }
  if(random_orders > 0){
    for(i in seq_len(random_orders)){
      add_order(paste0("random_", i), sample(seq_len(nrow(H))))
    }
  }
  if(length(order_list) == 0){stop("No valid ISS orders were supplied.")}
  results <- if(keep_results){vector("list", length(order_list))}else{NULL}
  if(keep_results){names(results) <- names(order_list)}
  table <- vector("list", length(order_list))
  i <- 0L
  for(name in names(order_list)){
    i <- i + 1L
    res <- est.subgraph(
      G = G,
      H = H,
      B = B,
      directed = directed,
      seed = if(is.null(seed)) NULL else seed + 100L * i,
      order = order_list[[name]],
      keep_mappings = FALSE,
      verbose = verbose,
      aut_count = aut_count,
      bootstrap_ci = bootstrap_ci,
      bootstrap_B = bootstrap_B,
      verbose.boot = verbose.boot,
      bootstrap_seed = if(is.null(seed)) NULL else seed + 10000L + 100L * i
    )
    if(keep_results){results[[name]] <- res}
    table[[i]] <- data.frame(
      order_name = name,
      order = paste(res$subgraph_order, collapse = " -> "),
      unlabeled_estimate = res$unlabeled_estimate,
      unlabeled_se = res$unlabeled_se,
      wald_lower = res$unlabeled_wald_ci_95[1],
      wald_upper = res$unlabeled_wald_ci_95[2],
      log_wald_lower = res$unlabeled_log_wald_ci_95[1],
      log_wald_upper = res$unlabeled_log_wald_ci_95[2],
      success_rate = res$success_rate,
      ess_ratio = res$weight_diagnostics$ess_ratio,
      cv_weight = res$weight_diagnostics$cv_weight,
      max_weight_share = res$weight_diagnostics$max_weight_share,
      row.names = NULL
    )
    if(verbose.sens){
      cat("Finished", name, "sensitivity test\n")
    }
  }
  out <- list(
    call = match.call(),
    sensitivity_table = do.call(rbind, table),
    results = results,
    B = B,
    directed = directed,
    graph_density = density,
    random_orders = random_orders
  )
  class(out) <- "iss.order.sensitivity"
  out
}
print.iss.order.sensitivity <- function(x, ...){
  cat("ISS order sensitivity analysis\n")
  cat("  samples:       ", x$B, "\n", sep = "")
  cat("  graph density: ", signif(x$graph_density, 4), "\n", sep = "")
  cat("\nSensitivity table\n")
  print(x$sensitivity_table, row.names = FALSE)
  invisible(x)
}
#==========================================================================
