rm(list=ls())
algo.path = "..."

source(file.path(algo.path, "ISS.R"))
source(file.path(algo.path, "TSGE.R"))

library(dplyr)
library(Matrix)
library(igraph)
#==============================Subgraph Estimation==============================
## Example:
G <- erdos.renyi.game(n = 1000, p = 0.01, directed = F)
H <- matrix(1, nrow = 3, ncol = 3)
res <- est.subgraph(G = G, H = H, B = 10000, bootstrap_B = 1000,
                    directed = F, seed = NULL, bootstrap_ci = T, verbose.boot = T)

G <- erdos.renyi.game(n = 50, p = 0.1, directed = F)
H <- matrix(c(0, 1, 1, 1, 1,
              1, 0, 1, 1, 0,
              1, 1, 0, 0, 0,
              1, 1, 0, 0, 0,
              1, 0, 0, 0, 0), nrow = 5, ncol = 5) %>%
sens <- iss.order.sensitivity(
  G, H,
  B = 100000,
  orders = c("mot.order", "reverse"),
  random_orders = 20
)
sens
#==============================Motif Verification==============================
## Example:
G <- erdos.renyi.game(n = 1000, p = 0.01, directed = F) %>%
  as_adjacency_matrix %>%
  as.matrix
H <- matrix(1, nrow = 3, ncol = 3) %>% 
  forceSymmetric() %>%
  as.matrix %>%
  `diag<-`(0)
res <- motif.test(
  G = G,
  H = H,
  B_observed = 10000,
  R_null = 10000,
  directed = F,
  null_model = 'chung_lu',
  verbose = T
  )
res
res.cal <- motif.test.cal(
  G = G, H = H,
  B_observed = 3000,
  R_null = 3000,
  K = 99,
  null_model = 'chung_lu',
  verbose = F
  )
res.cal