#==========================================================================
## Two-Stage Graph Estimation based on Induced-Sequential-Sampling algorithm
#==========================================================================
`%||%` <- function(x, y){if(is.null(x)) y else x}
log.sum <- function(x){
  finite <- is.finite(x)
  if(!any(finite)){return(-Inf)}
  m <- max(x[finite])
  m + log(sum(exp(x[finite] - m)))
}
w.mean <- function(log_w){
  exp(log.sum(log_w) - log(length(log_w)))
}
sample.var <- function(log_w){
  n <- length(log_w)
  if(n <= 1){return(NA_real_)}
  log_sum_w <- log.sum(log_w)
  log_sum_w2 <- log.sum(2 * log_w)
  mean_w <- exp(log_sum_w - log(n))
  sum_w2 <- exp(log_sum_w2)
  max((sum_w2 - n * mean_w^2)/(n - 1), 0)
}
if(!exists("iss.log.sum", mode = "function")){
  iss.log.sum <- log.sum
}
if(!exists("iss.log.mean", mode = "function")){
  iss.log.mean <- function(log_w){
    exp(iss.log.sum(log_w) - log(length(log_w)))
  }
}
if(!exists("iss.weight.diagnostics", mode = "function")){
  iss.weight.diagnostics <- function(weights){
    finite <- is.finite(weights)
    w <- weights[finite]
    n <- length(weights)
    finite_n <- length(w)
    zero_n <- sum(w == 0)
    total <- sum(w)
    sum_w2 <- sum(w^2)
    mean_w <- if(finite_n > 0){mean(w)}else{NA_real_}
    sd_w <- if(finite_n > 1){stats::sd(w)}else{NA_real_}
    ess <- if(is.finite(total) && total > 0 && is.finite(sum_w2) && sum_w2 > 0){
      total^2/sum_w2
    }else{0}
    list(
      n = n,
      finite = finite_n,
      zero_count = zero_n,
      zero_rate = if(finite_n > 0){zero_n/finite_n}else{NA_real_},
      positive_rate = if(finite_n > 0){mean(w > 0)}else{NA_real_},
      ess = ess,
      ess_ratio = if(finite_n > 0){ess/finite_n}else{NA_real_},
      cv_weight = if(is.finite(mean_w) && mean_w > 0 && is.finite(sd_w)){sd_w/mean_w}else{NA_real_},
      max_weight = if(finite_n > 0){max(w)}else{NA_real_},
      max_weight_share = if(is.finite(total) && total > 0){max(w)/total}else{NA_real_}
    )
  }
}
if(!exists("iss.log.weight.diagnostics", mode = "function")){
  iss.log.weight.diagnostics <- function(log_weights){
    finite <- is.finite(log_weights)
    if(!any(finite)){
      return(iss.weight.diagnostics(rep(0, length(log_weights))))
    }
    m <- max(log_weights[finite])
    weights <- exp(log_weights - m)
    weights[!is.finite(weights)] <- 0
    iss.weight.diagnostics(weights)
  }
}
if(!exists("iss.wald.ci", mode = "function")){
  iss.wald.ci <- function(estimate, se, level = 0.95){
    if(!is.finite(estimate) || !is.finite(se) || se < 0){return(c(NA_real_, NA_real_))}
    z <- stats::qnorm(1 - (1 - level)/2)
    estimate + c(-1, 1) * z * se
  }
}
if(!exists("iss.log.wald.ci", mode = "function")){
  iss.log.wald.ci <- function(estimate, se, level = 0.95){
    if(!is.finite(estimate) || estimate <= 0 || !is.finite(se) || se < 0){
      return(c(NA_real_, NA_real_))
    }
    z <- stats::qnorm(1 - (1 - level)/2)
    exp(log(estimate) + c(-1, 1) * z * se/estimate)
  }
}
if(!exists("iss.rare.weight.case", mode = "function")){
  iss.rare.weight.case <- function(diagnostics, success_rate = NULL,
                                   ess_ratio_threshold = 0.1,
                                   positive_rate_threshold = 0.1,
                                   max_weight_share_threshold = 0.1){
    rare <- FALSE
    if(!is.null(success_rate) && is.finite(success_rate)){
      rare <- rare || success_rate < positive_rate_threshold
    }
    if(!is.null(diagnostics)){
      rare <- rare ||
        (is.finite(diagnostics$ess_ratio) && diagnostics$ess_ratio < ess_ratio_threshold) ||
        (is.finite(diagnostics$positive_rate) && diagnostics$positive_rate < positive_rate_threshold) ||
        (is.finite(diagnostics$max_weight_share) &&
           diagnostics$max_weight_share > max_weight_share_threshold)
    }
    rare
  }
}
if(!exists("iss.bootstrap.mean.ci", mode = "function")){
  iss.bootstrap.mean.ci <- function(weights = NULL, log_weights = NULL, scale = 1,
                                    B_boot = 1000, level = 0.95, seed = NULL){
    if(!is.null(weights)){
      n <- length(weights)
    }else if(!is.null(log_weights)){
      n <- length(log_weights)
    }else{
      stop("Either weights or log_weights must be supplied.")
    }
    if(n < 1 || B_boot < 1){return(c(NA_real_, NA_real_))}
    if(!is.null(seed)){set.seed(seed)}
    estimates <- numeric(B_boot)
    for(b in seq_len(B_boot)){
      idx <- sample.int(n, n, replace = TRUE)
      estimates[b] <- if(!is.null(weights)){
        mean(weights[idx])/scale
      }else{
        iss.log.mean(log_weights[idx])/scale
      }
    }
    stats::quantile(estimates, probs = c((1 - level)/2, 1 - (1 - level)/2),
                    na.rm = TRUE, names = FALSE, type = 7)
  }
}
is.compact.probmat <- function(P){
  is.list(P) && !is.null(P$compact_probmat) && isTRUE(P$compact_probmat)
}
prob.n <- function(P){
  if(is.compact.probmat(P)){return(P$n)}
  nrow(P)
}
prob.dens <- function(P, directed = FALSE){
  if(is.compact.probmat(P)){return(P$density)}
  g.dens(P, directed = directed)
}
make.compact.probmat <- function(type, n, directed = FALSE, density = NA_real_,
                                 p = NULL, degree = NULL, out_degree = NULL,
                                 in_degree = NULL, m = NULL, cap = 1 - 1e-12){
  structure(
    list(
      compact_probmat = TRUE,
      type = type,
      n = as.integer(n),
      directed = directed,
      density = density,
      p = p,
      degree = degree,
      out_degree = out_degree,
      in_degree = in_degree,
      m = m,
      cap = cap
    ),
    class = c("compact.probmat", "list")
  )
}
prob.values <- function(P, from, to, eps = 1e-300){
  if(!is.compact.probmat(P)){
    return(pmin(pmax(P[cbind(from, to)], eps), 1 - 1e-12))
  }
  if(P$type == "erdos_renyi"){
    p <- rep(P$p, length(from))
  }else if(P$directed){
    p <- P$out_degree[from] * P$in_degree[to]/P$m
  }else{
    p <- P$degree[from] * P$degree[to]/(2 * P$m)
  }
  pmin(pmax(p, eps), P$cap)
}
compact.to.matrix <- function(P, max_entries = 5e7){
  if(!is.compact.probmat(P)){return(P)}
  if(P$n * P$n > max_entries){
    stop("This compact probability matrix is too large to expand safely.")
  }
  idx <- expand.grid(from = seq_len(P$n), to = seq_len(P$n))
  M <- matrix(prob.values(P, idx$from, idx$to, eps = 0), P$n, P$n)
  diag(M) <- 0
  if(!P$directed){
    M <- (M + t(M))/2
    diag(M) <- 0
  }
  M
}
norm.probmat <- function(P, directed = FALSE, cap = 1 - 1e-12){
  if(is.compact.probmat(P)){return(P)}
  P <- as.matrix(P)
  if(nrow(P) != ncol(P)){stop("P must be a square matrix.")}
  P[is.na(P)] <- 0
  P <- pmin(pmax(P, 0), cap)
  diag(P) <- 0
  if(!directed){
    P <- (P + t(P))/2
    diag(P) <- 0
  }
  return(P)
}
make.null <- function(G, method = c("chung_lu", "erdos_renyi"), directed = FALSE,
                      cap = 1 - 1e-12, compact_threshold = 5e7){
  method <- match.arg(method)
  G <- norm.graph(G, directed = directed)
  n <- nrow(G)
  use_compact <- (n * n) > compact_threshold
  if(method == "erdos_renyi"){
    p <- g.dens(G, directed = directed)
    if(use_compact){
      return(make.compact.probmat(
        type = "erdos_renyi",
        n = n,
        directed = directed,
        density = p,
        p = min(max(p, 0), cap),
        cap = cap
      ))
    }
    P <- matrix(p, n, n)
    diag(P) <- 0
    return(norm.probmat(P, directed = directed, cap = cap))
  }
  if(directed){
    m <- sum(G)
    if(m == 0){
      if(use_compact){
        return(make.compact.probmat(
          type = "erdos_renyi",
          n = n,
          directed = TRUE,
          density = 0,
          p = 0,
          cap = cap
        ))
      }
      return(matrix(0, n, n))
    }
    out_degree <- rowSums(G)
    in_degree <- colSums(G)
    if(use_compact){
      return(make.compact.probmat(
        type = "chung_lu",
        n = n,
        directed = TRUE,
        density = m/(n * (n - 1)),
        out_degree = out_degree,
        in_degree = in_degree,
        m = m,
        cap = cap
      ))
    }
    P <- outer(out_degree, in_degree, "*")/m
    diag(P) <- 0
    return(norm.probmat(P, directed = TRUE, cap = cap))
  }
  m <- sum(G)/2
  if(m == 0){
    if(use_compact){
      return(make.compact.probmat(
        type = "erdos_renyi",
        n = n,
        directed = FALSE,
        density = 0,
        p = 0,
        cap = cap
      ))
    }
    return(matrix(0, n, n))
  }
  degree <- rowSums(G)
  if(use_compact){
    return(make.compact.probmat(
      type = "chung_lu",
      n = n,
      directed = FALSE,
      density = m/choose(n, 2),
      degree = degree,
      m = m,
      cap = cap
    ))
  }
  P <- outer(degree, degree, "*")/(2 * m)
  diag(P) <- 0
  norm.probmat(P, directed = FALSE, cap = cap)
}
inc.logp <- function(P, H, order, step, mapping, candidate,
                                 directed = FALSE, eps = 1e-300){
  if(step == 1){return(0)}
  motif_node <- order[step]
  log_prob <- 0
  for(prev_step in seq_len(step - 1)){
    prev_motif <- order[prev_step]
    prev_graph <- mapping[prev_step]
    if(directed){
      p1 <- if(is.compact.probmat(P)){
        prob.values(P, candidate, prev_graph, eps = eps)
      }else{
        min(max(P[candidate, prev_graph], eps), 1 - 1e-12)
      }
      p2 <- if(is.compact.probmat(P)){
        prob.values(P, prev_graph, candidate, eps = eps)
      }else{
        min(max(P[prev_graph, candidate], eps), 1 - 1e-12)
      }
      log_prob <- log_prob +
        if(H[motif_node, prev_motif]) log(p1) else log1p(-p1)
      log_prob <- log_prob +
        if(H[prev_motif, motif_node]) log(p2) else log1p(-p2)
    }else{
      p <- if(is.compact.probmat(P)){
        prob.values(P, candidate, prev_graph, eps = eps)
      }else{
        min(max(P[candidate, prev_graph], eps), 1 - 1e-12)
      }
      log_prob <- log_prob +
        if(H[motif_node, prev_motif]) log(p) else log1p(-p)
    }
  }
  return(log_prob)
}
candidate.logp <- function(P, H, order, step, mapping, candidates,
                           directed = FALSE, eps = 1e-300){
  if(step == 1){return(rep(0, length(candidates)))}
  motif_node <- order[step]
  log_prob <- numeric(length(candidates))
  for(prev_step in seq_len(step - 1)){
    prev_motif <- order[prev_step]
    prev_graph <- mapping[prev_step]
    if(directed){
      p1 <- if(is.compact.probmat(P)){
        prob.values(P, candidates, rep(prev_graph, length(candidates)), eps = eps)
      }else{
        pmin(pmax(P[candidates, prev_graph], eps), 1 - 1e-12)
      }
      p2 <- if(is.compact.probmat(P)){
        prob.values(P, rep(prev_graph, length(candidates)), candidates, eps = eps)
      }else{
        pmin(pmax(P[prev_graph, candidates], eps), 1 - 1e-12)
      }
      log_prob <- log_prob +
        if(H[motif_node, prev_motif]) log(p1) else log1p(-p1)
      log_prob <- log_prob +
        if(H[prev_motif, motif_node]) log(p2) else log1p(-p2)
    }else{
      p <- if(is.compact.probmat(P)){
        prob.values(P, candidates, rep(prev_graph, length(candidates)), eps = eps)
      }else{
        pmin(pmax(P[candidates, prev_graph], eps), 1 - 1e-12)
      }
      log_prob <- log_prob +
        if(H[motif_node, prev_motif]) log(p) else log1p(-p)
    }
  }
  return(log_prob)
}
candidate.logp.chunglu <- function(P, H, order, step, mapping, candidates,
                                   directed = FALSE, eps = 1e-300){
  if(step == 1){return(rep(0, length(candidates)))}
  motif_node <- order[step]
  log_prob <- numeric(length(candidates))
  upper <- min(P$cap, 1 - 1e-12)
  add_edge_terms <- function(log_prob, candidate_score, factors){
    if(length(factors) == 0){return(log_prob)}
    if(max(candidate_score) * max(factors) > upper){
      for(factor in factors){
        p <- pmin(pmax(candidate_score * factor, eps), upper)
        log_prob <- log_prob + log(p)
      }
      return(log_prob)
    }
    positive_factor <- factors > 0
    zero_factor_count <- sum(!positive_factor)
    positive_factors <- factors[positive_factor]
    positive_candidate <- candidate_score > 0
    if(length(positive_factors) > 0){
      constant <- sum(log(positive_factors))
      log_prob[positive_candidate] <- log_prob[positive_candidate] +
        length(positive_factors) * log(candidate_score[positive_candidate]) + constant
      log_prob[!positive_candidate] <- log_prob[!positive_candidate] +
        length(positive_factors) * log(eps)
    }
    if(zero_factor_count > 0){
      log_prob <- log_prob + zero_factor_count * log(eps)
    }
    log_prob
  }
  if(directed){
    cand_out <- P$out_degree[candidates]
    cand_in <- P$in_degree[candidates]
    prev_steps <- seq_len(step - 1)
    prev_motifs <- order[prev_steps]
    prev_graphs <- mapping[prev_steps]
    out_edge <- H[motif_node, prev_motifs]
    in_edge <- H[prev_motifs, motif_node]
    log_prob <- add_edge_terms(log_prob, cand_out, P$in_degree[prev_graphs[out_edge]]/P$m)
    log_prob <- add_edge_terms(log_prob, cand_in, P$out_degree[prev_graphs[in_edge]]/P$m)
    if(any(!out_edge)){
      for(prev_graph in prev_graphs[!out_edge]){
        p1 <- pmin(pmax(cand_out * P$in_degree[prev_graph]/P$m, eps), upper)
        log_prob <- log_prob + log1p(-p1)
      }
    }
    if(any(!in_edge)){
      for(prev_graph in prev_graphs[!in_edge]){
        p2 <- pmin(pmax(P$out_degree[prev_graph] * cand_in/P$m, eps), upper)
        log_prob <- log_prob + log1p(-p2)
      }
    }
  }else{
    cand_degree <- P$degree[candidates]
    denom <- 2 * P$m
    prev_steps <- seq_len(step - 1)
    prev_motifs <- order[prev_steps]
    prev_graphs <- mapping[prev_steps]
    edge <- H[motif_node, prev_motifs]
    log_prob <- add_edge_terms(log_prob, cand_degree, P$degree[prev_graphs[edge]]/denom)
    if(any(!edge)){
      for(prev_graph in prev_graphs[!edge]){
        p <- pmin(pmax(cand_degree * P$degree[prev_graph]/denom, eps), upper)
        log_prob <- log_prob + log1p(-p)
      }
    }
  }
  return(log_prob)
}
sample.null <- function(P, H, order, directed = FALSE){
  n <- prob.n(P)
  k <- nrow(H)
  mapping <- integer(k)
  used <- rep(FALSE, n)
  log_weight <- 0
  for(step in seq_len(k)){
    candidates <- which(!used)
    if(is.compact.probmat(P) && P$type == "erdos_renyi"){
      motif_node <- order[step]
      imposed_edges <- 0L
      imposed_non_edges <- 0L
      if(step > 1){
        for(prev_step in seq_len(step - 1)){
          prev_motif <- order[prev_step]
          if(directed){
            imposed_edges <- imposed_edges + H[motif_node, prev_motif] + H[prev_motif, motif_node]
            imposed_non_edges <- imposed_non_edges + (!H[motif_node, prev_motif]) + (!H[prev_motif, motif_node])
          }else{
            imposed_edges <- imposed_edges + H[motif_node, prev_motif]
            imposed_non_edges <- imposed_non_edges + (!H[motif_node, prev_motif])
          }
        }
      }
      p <- min(max(P$p, 1e-300), 1 - 1e-12)
      log_g_const <- imposed_edges * log(p) + imposed_non_edges * log1p(-p)
      log_z <- log(length(candidates)) + log_g_const
      chosen <- if(length(candidates) == 1){
        candidates
      }else{
        sample(candidates, 1)
      }
    }else if(is.compact.probmat(P) && P$type == "chung_lu"){
      log_g <- candidate.logp.chunglu(P = P, H = H, order = order, step = step,
                                      mapping = mapping, candidates = candidates,
                                      directed = directed)
      log_z <- log.sum(log_g)
      if(!is.finite(log_z)){return(-Inf)}
      probs <- exp(log_g - log_z)
      chosen <- if(length(candidates) == 1){
        candidates
      }else{
        sample(candidates, 1, prob = probs)
      }
    }else{
      log_g <- candidate.logp(P = P, H = H, order = order, step = step,
                              mapping = mapping, candidates = candidates,
                              directed = directed)
      log_z <- log.sum(log_g)
      if(!is.finite(log_z)){return(-Inf)}
      probs <- exp(log_g - log_z)
      chosen <- if(length(candidates) == 1){
        candidates
      }else{
        sample(candidates, 1, prob = probs)
      }
    }
    if(!is.finite(log_z)){return(-Inf)}
    mapping[step] <- chosen
    used[chosen] <- TRUE
    log_weight <- log_weight + log_z
  }
  return(log_weight)
}
est.null <- function(P, H, R = 10000, directed = FALSE, seed = NULL,
                     order = NULL, automorphism_count_value = NULL, verbose = TRUE,
                     bootstrap_ci = FALSE, bootstrap_B = 1000,
                     bootstrap_seed = NULL){
  if(!is.numeric(R) || length(R) != 1 || is.na(R) || R < 1 || R != as.integer(R)){
    stop("R must be a positive integer.")
  }
  R <- as.integer(R)
  if(!is.null(seed)){set.seed(seed)}
  P <- norm.probmat(P, directed = directed)
  H <- norm.graph(H, directed = directed)
  if(nrow(H) > prob.n(P)){stop("The motif cannot have more nodes than the null probability matrix.")}
  
  if(is.null(order)){
    order <- mot.order(H, prob.dens(P, directed = directed), directed = directed)
  }
  if(is.null(automorphism_count_value)){
    automorphism_count_value <- aut.morph(H, directed = directed)
  }
  log_weights <- numeric(R)
  for(r in seq_len(R)){
    log_weights[r] <- sample.null(P = P, H = H, order = order, directed = directed)
    if(verbose && R >= 10 && r %% max(1, floor(R/10)) == 0){
      cat("Finished", r, "of", R, "null-model samples\n")
    }
  }
  labeled_estimate <- w.mean(log_weights)
  labeled_var <- sample.var(log_weights)
  labeled_se <- sqrt(labeled_var/R)
  unlabeled_estimate <- labeled_estimate/automorphism_count_value
  unlabeled_se <- labeled_se/automorphism_count_value
  labeled_wald_ci_95 <- iss.wald.ci(labeled_estimate, labeled_se)
  unlabeled_wald_ci_95 <- iss.wald.ci(unlabeled_estimate, unlabeled_se)
  labeled_log_wald_ci_95 <- iss.log.wald.ci(labeled_estimate, labeled_se)
  unlabeled_log_wald_ci_95 <- iss.log.wald.ci(unlabeled_estimate, unlabeled_se)
  diagnostics <- iss.log.weight.diagnostics(log_weights)
  bootstrap <- NULL
  if(isTRUE(bootstrap_ci)){
    bootstrap <- list(
      labeled_ci_95 = iss.bootstrap.mean.ci(
        log_weights = log_weights,
        scale = 1,
        B_boot = bootstrap_B,
        seed = bootstrap_seed
      ),
      unlabeled_ci_95 = iss.bootstrap.mean.ci(
        log_weights = log_weights,
        scale = automorphism_count_value,
        B_boot = bootstrap_B,
        seed = if(is.null(bootstrap_seed)) NULL else bootstrap_seed + 1L
      ),
      B = bootstrap_B,
      method = "nonparametric bootstrap"
    )
  }
  result <- list(R = R,
    directed = directed,
    graph_nodes = prob.n(P),
    motif_nodes = nrow(H),
    motif_order = order,
    automorphism_count = automorphism_count_value,
    labeled_expectation = labeled_estimate,
    labeled_se = labeled_se,
    labeled_ci_95 = labeled_wald_ci_95,
    labeled_wald_ci_95 = labeled_wald_ci_95,
    labeled_log_wald_ci_95 = labeled_log_wald_ci_95,
    unlabeled_expectation = unlabeled_estimate,
    unlabeled_se = unlabeled_se,
    unlabeled_ci_95 = unlabeled_wald_ci_95,
    unlabeled_wald_ci_95 = unlabeled_wald_ci_95,
    unlabeled_log_wald_ci_95 = unlabeled_log_wald_ci_95,
    ci_method = "Wald",
    supplemental_ci_method = "log-scale Wald",
    weight_diagnostics = diagnostics,
    bootstrap_ci = bootstrap,
    log_weights = log_weights)
  class(result) <- "null.exp"
  return(result)
}
wald.p <- function(z, alternative = c("greater", "less", "two.sided")){
  alternative <- match.arg(alternative)
  if(alternative == "greater"){return(stats::pnorm(z, lower.tail = FALSE))}
  if(alternative == "less"){return(stats::pnorm(z, lower.tail = TRUE))}
  2 * stats::pnorm(abs(z), lower.tail = FALSE)
}
validate.motif.order <- function(order, H, name = "order"){
  k <- nrow(H)
  if(!is.numeric(order) && !is.integer(order)){
    stop(name, " must be a numeric permutation of motif node indices.")
  }
  if(length(order) != k || !setequal(order, seq_len(k))){
    stop(name, " must be a permutation of motif node indices.")
  }
  as.integer(order)
}
resolve.null.order <- function(order_null = NULL, H, P = NULL, observed_order,
                               directed = FALSE){
  observed_order <- validate.motif.order(observed_order, H, name = "observed_order")
  if(is.null(order_null)){
    return(observed_order)
  }
  if(is.character(order_null) && length(order_null) == 1){
    if(order_null %in% c("observed", "same", "default")){
      return(observed_order)
    }
    if(order_null == "null_density"){
      if(is.null(P)){
        stop("P must be supplied when order_null = 'null_density'.")
      }
      return(mot.order(H, prob.dens(P, directed = directed), directed = directed))
    }
    if(order_null == "reverse"){
      return(rev(observed_order))
    }
    stop("Unknown order_null option: ", order_null)
  }
  validate.motif.order(order_null, H, name = "order_null")
}
motif.test <- function(G, H, B_observed = 10000, R_null = 10000, directed = FALSE,
                       null_model = c("chung_lu", "erdos_renyi", "given"), P_null = NULL,
                       null_variance = c("poisson", "none", "provided"), tau2_null = NULL,
                       alternative = c("greater", "less", "two.sided"), seed = NULL,
                       order = NULL, order_null = NULL,
                       automorphism_count_value = NULL, verbose = TRUE,
                       bootstrap_ci = FALSE, bootstrap_B = 1000,
                       bootstrap_seed = NULL){
  null_model <- match.arg(null_model)
  null_variance <- match.arg(null_variance)
  alternative <- match.arg(alternative)
  if(!is.null(seed)){set.seed(seed)}
  G <- norm.graph(G, directed = directed)
  H <- norm.graph(H, directed = directed)
  if(is.null(order)){
    density <- g.dens(G, directed = directed)
    order <- mot.order(H, density, directed = directed)
  }
  if(is.null(automorphism_count_value)){
    automorphism_count_value <- aut.morph(H, directed = directed)
  }
  observed_args <- list(G = G, H = H, B = B_observed,
    directed = directed, seed = if(is.null(seed)) NULL else seed + 1L,
    order = order, keep_mappings = FALSE, verbose = verbose,
    bootstrap_ci = bootstrap_ci,
    bootstrap_B = bootstrap_B,
    bootstrap_seed = bootstrap_seed %||% if(is.null(seed)) NULL else seed + 4L)
  observed <- do.call(est.subgraph, observed_args)
  P <- if(null_model == "given"){
    if(is.null(P_null)){stop("P_null must be supplied when null_model = 'given'.")}
    norm.probmat(P_null, directed = directed)
  }else{
    make.null(G, method = null_model, directed = directed)
  }
  null_order <- resolve.null.order(order_null = order_null, H = H, P = P,
                                   observed_order = order, directed = directed)
  null_expectation <- est.null(P = P, H = H, R = R_null, directed = directed,
    seed = if(is.null(seed)) NULL else seed + 2L,order = null_order,
    automorphism_count_value = automorphism_count_value, verbose = verbose,
    bootstrap_ci = bootstrap_ci,
    bootstrap_B = bootstrap_B,
    bootstrap_seed = if(is.null(bootstrap_seed)){
      if(is.null(seed)) NULL else seed + 5L
    }else{
      bootstrap_seed + 1L
    })
  theta <- observed$unlabeled_estimate
  theta_se <- observed$unlabeled_se
  mu0 <- null_expectation$unlabeled_expectation
  mu0_se <- null_expectation$unlabeled_se
  if(theta <= 0 || mu0 <= 0){
    warning("theta or mu0 is non-positive; log enrichment is undefined. Returning NA coefficient.")
    beta <- NA_real_
    beta_se_mc <- NA_real_
    beta_se_total <- NA_real_
    z <- NA_real_
    p <- NA_real_
  }else{
    beta <- log(theta/mu0)
    beta_se_mc <- sqrt((theta_se/theta)^2 + (mu0_se/mu0)^2)
    if(null_variance == "poisson"){
      tau2 <- mu0
    }else if(null_variance == "provided"){
      if(is.null(tau2_null) || !is.numeric(tau2_null) || length(tau2_null) != 1 ||
          is.na(tau2_null) || tau2_null < 0){
        stop("tau2_null must be a non-negative number when null_variance = 'provided'.")
      }
      tau2 <- tau2_null
    }else{
      tau2 <- 0
    }
    beta_se_total <- sqrt(beta_se_mc^2 + tau2/(mu0^2))
    z <- beta/beta_se_total
    p <- wald.p(z, alternative = alternative)
  }
  excess <- theta - mu0
  excess_se_mc <- sqrt(theta_se^2 + mu0_se^2)
  if(null_variance == "poisson"){
    excess_tau2 <- mu0
  }else if(null_variance == "provided"){
    excess_tau2 <- tau2_null
  }else{
    excess_tau2 <- 0
  }
  excess_se_total <- sqrt(excess_se_mc^2 + excess_tau2)
  excess_z <- excess/excess_se_total
  excess_p <- wald.p(excess_z, alternative = alternative)
  coefficients <- data.frame(
    term = "log_enrichment",
    estimate = beta,
    std.error = beta_se_total,
    statistic = z,
    p.value = p,
    row.names = NULL)
  auxiliary <- data.frame(
    term = "excess_count",
    estimate = excess,
    std.error = excess_se_total,
    statistic = excess_z,
    p.value = excess_p,
    row.names = NULL
  )
  bootstrap_inference <- NULL
  if(isTRUE(bootstrap_ci)){
    if(!is.null(bootstrap_seed)){set.seed(bootstrap_seed + 2L)}
    beta_boot <- rep(NA_real_, bootstrap_B)
    ratio_boot <- rep(NA_real_, bootstrap_B)
    excess_boot <- rep(NA_real_, bootstrap_B)
    for(b in seq_len(bootstrap_B)){
      obs_idx <- sample.int(length(observed$weights), length(observed$weights), replace = TRUE)
      null_idx <- sample.int(length(null_expectation$log_weights),
                             length(null_expectation$log_weights), replace = TRUE)
      theta_b <- mean(observed$weights[obs_idx])/automorphism_count_value
      mu0_b <- iss.log.mean(null_expectation$log_weights[null_idx])/automorphism_count_value
      if(is.finite(theta_b) && theta_b > 0 && is.finite(mu0_b) && mu0_b > 0){
        beta_boot[b] <- log(theta_b/mu0_b)
        ratio_boot[b] <- theta_b/mu0_b
      }
      if(is.finite(theta_b) && is.finite(mu0_b)){
        excess_boot[b] <- theta_b - mu0_b
      }
    }
    bootstrap_inference <- list(
      method = "nonparametric bootstrap over ISS weights",
      B = bootstrap_B,
      observed_count_ci_95 = observed$bootstrap_ci$unlabeled_ci_95,
      null_expectation_ci_95 = null_expectation$bootstrap_ci$unlabeled_ci_95,
      log_enrichment_ci_95 = stats::quantile(beta_boot, c(0.025, 0.975),
                                             na.rm = TRUE, names = FALSE, type = 7),
      enrichment_ratio_ci_95 = stats::quantile(ratio_boot, c(0.025, 0.975),
                                               na.rm = TRUE, names = FALSE, type = 7),
      excess_ci_95 = stats::quantile(excess_boot, c(0.025, 0.975),
                                     na.rm = TRUE, names = FALSE, type = 7)
    )
  }
  result <- list(
    call = match.call(),
    coefficient_table = coefficients,
    auxiliary_table = auxiliary,
    alternative = alternative,
    null_model = null_model,
    null_variance = null_variance,
    motif_order = order,
    null_motif_order = null_order,
    automorphism_count = automorphism_count_value,
    observed = observed,
    null_expectation = null_expectation,
    bootstrap_ci = bootstrap_inference,
    estimates = list(
      observed_count = theta,
      observed_se = theta_se,
      observed_wald_ci_95 = observed$unlabeled_wald_ci_95,
      observed_log_wald_ci_95 = observed$unlabeled_log_wald_ci_95,
      null_expectation = mu0,
      null_expectation_se = mu0_se,
      null_expectation_wald_ci_95 = null_expectation$unlabeled_wald_ci_95,
      null_expectation_log_wald_ci_95 = null_expectation$unlabeled_log_wald_ci_95,
      enrichment_ratio = if(mu0 > 0) theta/mu0 else NA_real_,
      log_enrichment = beta,
      log_enrichment_se_mc = beta_se_mc,
      log_enrichment_se_total = beta_se_total,
      log_enrichment_ci_95 = iss.wald.ci(beta, beta_se_total),
      excess = excess,
      excess_se_mc = excess_se_mc,
      excess_se_total = excess_se_total,
      excess_ci_95 = iss.wald.ci(excess, excess_se_total),
      excess_z = excess_z,
      excess_p_value = excess_p
    )
  )
  class(result) <- "motif.test"
  return(result)
}
print.motif.test <- function(x, ...){
  cat("TSGE motif test\n")
  cat("  null model:       ", x$null_model, "\n", sep = "")
  cat("  null variance:    ", x$null_variance, "\n", sep = "")
  cat("  alternative:      ", x$alternative, "\n", sep = "")
  cat("  motif order:      ", paste(x$motif_order, collapse = " -> "), "\n", sep = "")
  if(!is.null(x$null_motif_order) && !identical(x$null_motif_order, x$motif_order)){
    cat("  null motif order: ", paste(x$null_motif_order, collapse = " -> "), "\n", sep = "")
  }
  cat("  automorphisms:    ", x$automorphism_count, "\n", sep = "")
  cat("\nCounts\n")
  cat("  observed count:   ", signif(x$estimates$observed_count, 6),
      " (SE ", signif(x$estimates$observed_se, 4), ")\n", sep = "")
  cat("  observed Wald 95% CI: [", signif(x$estimates$observed_wald_ci_95[1], 6),
      ", ", signif(x$estimates$observed_wald_ci_95[2], 6), "]\n", sep = "")
  cat("  null expectation: ", signif(x$estimates$null_expectation, 6),
      " (SE ", signif(x$estimates$null_expectation_se, 4), ")\n", sep = "")
  cat("  null Wald 95% CI: [", signif(x$estimates$null_expectation_wald_ci_95[1], 6),
      ", ", signif(x$estimates$null_expectation_wald_ci_95[2], 6), "]\n", sep = "")
  cat("  beta = log(theta/mu0): ", signif(x$estimates$log_enrichment, 6),
      " (total SE ", signif(x$estimates$log_enrichment_se_total, 4), ")\n", sep = "")
  cat("  beta Wald 95% CI: [", signif(x$estimates$log_enrichment_ci_95[1], 6),
      ", ", signif(x$estimates$log_enrichment_ci_95[2], 6), "]\n", sep = "")
  cat("  exp(beta):        ", signif(x$estimates$enrichment_ratio, 6), "\n", sep = "")
  if(!is.null(x$observed$weight_diagnostics) && !is.null(x$null_expectation$weight_diagnostics)){
    cat("\nWeight diagnostics\n")
    cat("  observed ESS ratio: ", signif(x$observed$weight_diagnostics$ess_ratio, 4),
        "; max weight share: ", signif(x$observed$weight_diagnostics$max_weight_share, 4), "\n", sep = "")
    cat("  null ESS ratio:     ", signif(x$null_expectation$weight_diagnostics$ess_ratio, 4),
        "; max weight share: ", signif(x$null_expectation$weight_diagnostics$max_weight_share, 4), "\n", sep = "")
  }
  rare_observed <- iss.rare.weight.case(x$observed$weight_diagnostics,
                                        success_rate = x$observed$success_rate)
  rare_null <- iss.rare.weight.case(x$null_expectation$weight_diagnostics)
  show_rare_observed <- rare_observed && all(is.finite(x$estimates$observed_log_wald_ci_95))
  show_rare_null <- rare_null && all(is.finite(x$estimates$null_expectation_log_wald_ci_95))
  if(show_rare_observed || show_rare_null){
    cat("\nSupplemental log-scale Wald intervals\n")
    if(show_rare_observed){
      cat("  observed count 95% CI: [", signif(x$estimates$observed_log_wald_ci_95[1], 6),
          ", ", signif(x$estimates$observed_log_wald_ci_95[2], 6), "]\n", sep = "")
    }
    if(show_rare_null){
      cat("  null expectation 95% CI: [", signif(x$estimates$null_expectation_log_wald_ci_95[1], 6),
          ", ", signif(x$estimates$null_expectation_log_wald_ci_95[2], 6), "]\n", sep = "")
    }
  }
  if(!is.null(x$bootstrap_ci)){
    cat("\nBootstrap robustness intervals\n")
    cat("  observed count 95% CI: [", signif(x$bootstrap_ci$observed_count_ci_95[1], 6),
        ", ", signif(x$bootstrap_ci$observed_count_ci_95[2], 6), "]\n", sep = "")
    cat("  null expectation 95% CI: [", signif(x$bootstrap_ci$null_expectation_ci_95[1], 6),
        ", ", signif(x$bootstrap_ci$null_expectation_ci_95[2], 6), "]\n", sep = "")
    cat("  beta 95% CI: [", signif(x$bootstrap_ci$log_enrichment_ci_95[1], 6),
        ", ", signif(x$bootstrap_ci$log_enrichment_ci_95[2], 6), "]\n", sep = "")
  }
  cat("\nCoefficient table\n")
  print(x$coefficient_table, row.names = FALSE)
  ## cat("\nAuxiliary count-difference table\n")
  ## print(x$auxiliary_table, row.names = FALSE)
  invisible(x)
}
summary.motif.test <- function(object, ...){
  list(coefficients = object$coefficient_table,
    auxiliary = object$auxiliary_table)
}
sample.g <- function(P, directed = FALSE){
  P <- norm.probmat(P, directed = directed)
  n <- prob.n(P)
  G <- matrix(FALSE, n, n)
  if(is.compact.probmat(P)){
    if(directed){
      nodes <- seq_len(n)
      for(i in nodes){
        to <- nodes[-i]
        probs <- prob.values(P, rep(i, length(to)), to, eps = 0)
        G[i, to] <- as.logical(stats::rbinom(length(to), 1, probs))
      }
      diag(G) <- FALSE
      return(G)
    }
    if(n > 1){
      for(i in seq_len(n - 1L)){
        to <- (i + 1L):n
        probs <- prob.values(P, rep(i, length(to)), to, eps = 0)
        G[i, to] <- as.logical(stats::rbinom(length(to), 1, probs))
      }
    }
    G <- G | t(G)
    diag(G) <- FALSE
    return(G)
  }
  if(directed){
    mask <- row(P) != col(P)
    G[mask] <- as.logical(stats::rbinom(sum(mask), 1, P[mask]))
    diag(G) <- FALSE
    return(G)
  }
  mask <- upper.tri(P)
  G[mask] <- as.logical(stats::rbinom(sum(mask), 1, P[mask]))
  G <- G | t(G)
  diag(G) <- FALSE
  return(G)
}
randomize <- function(G, n_swap = NULL, max_tries = NULL,
                                        directed = FALSE){
  G <- norm.graph(G, directed = directed)
  n <- nrow(G)
  if(directed){
    edges <- which(G, arr.ind = TRUE)
    m <- nrow(edges)
    if(m < 2){return(G)}
    if(is.null(n_swap)){n_swap <- 10L * m}
    if(is.null(max_tries)){max_tries <- 50L * n_swap}
    swaps <- 0L
    tries <- 0L
    while (swaps < n_swap && tries < max_tries){
      tries <- tries + 1L
      idx <- sample.int(m, 2)
      a <- edges[idx[1], 1]
      b <- edges[idx[1], 2]
      c <- edges[idx[2], 1]
      d <- edges[idx[2], 2]
      if(a == c || b == d || a == d || c == b){next}
      if(G[a, d] || G[c, b]){next}
      G[a, b] <- FALSE
      G[c, d] <- FALSE
      G[a, d] <- TRUE
      G[c, b] <- TRUE
      edges[idx[1], ] <- c(a, d)
      edges[idx[2], ] <- c(c, b)
      swaps <- swaps + 1L
    }
    return(G)
  }
  edges <- which(upper.tri(G) & G, arr.ind = TRUE)
  m <- nrow(edges)
  if(m < 2){return(G)}
  if(is.null(n_swap)){n_swap <- 10L * m}
  if(is.null(max_tries)){max_tries <- 50L * n_swap}
  sorted_edge <- function(x, y){
    if(x < y) c(x, y) else c(y, x)
  }
  swaps <- 0L
  tries <- 0L
  while (swaps < n_swap && tries < max_tries){
    tries <- tries + 1L
    idx <- sample.int(m, 2)
    a <- edges[idx[1], 1]
    b <- edges[idx[1], 2]
    c <- edges[idx[2], 1]
    d <- edges[idx[2], 2]
    if(length(unique(c(a, b, c, d))) < 4){next}
    if(stats::runif(1) < 0.5){
      e1 <- sorted_edge(a, d)
      e2 <- sorted_edge(c, b)
    }else{
      e1 <- sorted_edge(a, c)
      e2 <- sorted_edge(b, d)
    }
    if(identical(e1, e2)){next}
    if(G[e1[1], e1[2]] || G[e2[1], e2[2]]){next}
    G[a, b] <- G[b, a] <- FALSE
    G[c, d] <- G[d, c] <- FALSE
    G[e1[1], e1[2]] <- G[e1[2], e1[1]] <- TRUE
    G[e2[1], e2[2]] <- G[e2[2], e2[1]] <- TRUE
    edges[idx[1], ] <- e1
    edges[idx[2], ] <- e2
    swaps <- swaps + 1L
  }
  return(G)
}
cal.stat <- function(count, mu0, statistic = c("log_enrichment", "count", "excess"), log_offset = 0){
  statistic <- match.arg(statistic)
  if(statistic == "count"){return(count)}
  if(statistic == "excess"){return(count - mu0)}
  log((count + log_offset)/(mu0 + log_offset))
}
emp.p <- function(observed, null_values, center, alternative = c("greater", "less", "two.sided")){
  alternative <- match.arg(alternative)
  if(alternative == "greater"){
    return((1 + sum(null_values >= observed, na.rm = TRUE))/(length(null_values) + 1))
  }
  if(alternative == "less"){
    return((1 + sum(null_values <= observed, na.rm = TRUE))/(length(null_values) + 1))
  }
  (1 + sum(abs(null_values - center) >= abs(observed - center), na.rm = TRUE)) /
    (length(null_values) + 1)
}
motif.test.cal <- function(G, H, enrichment_result = NULL, K = 99, R_null = 10000, B_observed = 10000,
                           directed = FALSE, null_model = NULL, P_null = NULL, statistic = c("log_enrichment", "count", "excess"),
                           alternative = c("greater", "less", "two.sided"), seed = NULL, order = NULL,
                           order_null = NULL,
                           automorphism_count_value = NULL, null_expectation_value = NULL,
                           degree_swap_steps = NULL, log_offset = 0, verbose = TRUE, verbose.K = TRUE){
  statistic <- match.arg(statistic)
  alternative <- match.arg(alternative)
  if(!is.numeric(K) || length(K) != 1 || is.na(K) || K < 1 || K != as.integer(K)){
    stop("K must be a positive integer.")
  }
  if(!is.numeric(R_null) || length(R_null) != 1 || is.na(R_null) ||
      R_null < 1 || R_null != as.integer(R_null)){
    stop("R_null must be a positive integer.")
  }
  K <- as.integer(K)
  R_null <- as.integer(R_null)
  if(!is.null(seed)){set.seed(seed)}
  G <- norm.graph(G, directed = directed)
  H <- norm.graph(H, directed = directed)
  if(!is.null(enrichment_result)){
    if(is.null(null_model)) null_model <- enrichment_result$null_model
    if(is.null(order)) order <- enrichment_result$motif_order
    if(is.null(order_null) && !is.null(enrichment_result$null_motif_order)){
      order_null <- enrichment_result$null_motif_order
    }
    if(is.null(automorphism_count_value)){
      automorphism_count_value <- enrichment_result$automorphism_count
    }
    if(is.null(null_expectation_value)){
      null_expectation_value <- enrichment_result$estimates$null_expectation
    }
    observed_count <- enrichment_result$estimates$observed_count
    observed_count_se <- enrichment_result$estimates$observed_se
  }else{
    observed_count <- NULL
    observed_count_se <- NULL
  }
  if(is.null(null_model)) null_model <- "chung_lu"
  null_model <- match.arg(null_model, c("chung_lu", "erdos_renyi", "given", "degree_swap"))
  if(is.null(order)){
    order <- mot.order(H, g.dens(G, directed = directed), directed = directed)
  }
  if(is.null(automorphism_count_value)){
    automorphism_count_value <- aut.morph(H, directed = directed)
  }
  if(is.null(observed_count)){
    observed_args <- list(G = G, H = H, B = B_observed,
      directed = directed, seed = if(is.null(seed)) NULL else seed + 1L,
      order = order, keep_mappings = FALSE, verbose = verbose)
    observed <- do.call(est.subgraph, observed_args)
    observed_count <- observed$unlabeled_estimate
    observed_count_se <- observed$unlabeled_se
  }
  P <- NULL
  if(null_model == "given"){
    if(is.null(P_null)) stop("P_null must be supplied when null_model = 'given'.")
    P <- norm.probmat(P_null, directed = directed)
  }else if(null_model %in% c("chung_lu", "erdos_renyi")){
    P <- make.null(G, method = null_model, directed = directed)
  }
  random_order <- if(null_model == "degree_swap" &&
      is.character(order_null) && identical(order_null, "null_density")){
    order
  }else{
    resolve.null.order(order_null = order_null, H = H, P = P,
                       observed_order = order, directed = directed)
  }
  random_counts <- numeric(K)
  random_ses <- numeric(K)
  for(i in seq_len(K)){
    G_star <- if(null_model == "degree_swap"){
      randomize(G, n_swap = degree_swap_steps, directed = directed)
    }else{
      sample.g(P, directed = directed)
    }
    random_args <- list(G = G_star,
      H = H,
      B = R_null,
      directed = directed,
      seed = NULL,
      order = random_order,
      keep_mappings = FALSE,
      verbose = verbose)
    random_est <- do.call(est.subgraph, random_args)
    random_counts[i] <- random_est$unlabeled_estimate
    random_ses[i] <- random_est$unlabeled_se
    if(verbose.K && K >= 10 && i %% max(1, floor(K/10)) == 0){
      cat("Finished", i, "of", K, "random-network calibrations\n")
    }
  }
  if(is.null(null_expectation_value)){null_expectation_value <- mean(random_counts)}
  observed_stat <- cal.stat(
    observed_count,
    null_expectation_value,
    statistic = statistic,
    log_offset = log_offset
  )
  random_stats <- vapply(
    random_counts,
    cal.stat,
    numeric(1),
    mu0 = null_expectation_value,
    statistic = statistic,
    log_offset = log_offset
  )
  center <- switch(statistic,
    count = null_expectation_value,
    log_enrichment = 0,
    excess = 0)
  finite_stats <- random_stats[is.finite(random_stats)]
  if(length(finite_stats) < length(random_stats)){
    warning("Some calibrated statistics are non-finite. Consider setting log_offset > 0.")
  }
  empirical_p <- emp.p(observed = observed_stat,
    null_values = random_stats,center = center,
    alternative = alternative)
  null_mean <- if(length(finite_stats) > 0) mean(finite_stats) else NA_real_
  null_sd <- if(length(finite_stats) > 1) stats::sd(finite_stats) else NA_real_
  calibrated_z <- if(is.finite(observed_stat) && is.finite(null_sd) && null_sd > 0){
    (observed_stat - null_mean)/null_sd
  }else{NA_real_}
  table <- data.frame(
    term = paste0("calibrated_", statistic),
    estimate = observed_stat,
    null.mean = null_mean,
    null.sd = null_sd,
    statistic = calibrated_z,
    p.value = wald.p(calibrated_z, alternative = alternative),
    row.names = NULL
  )
  result <- list(
    call = match.call(),
    calibration_table = table,
    statistic = statistic,
    alternative = alternative,
    null_model = null_model,
    K = K,
    R_null = R_null,
    observed_count = observed_count,
    observed_count_se = observed_count_se,
    null_expectation = null_expectation_value,
    random_counts = random_counts,
    random_count_ses = random_ses,
    observed_statistic = observed_stat,
    random_statistics = random_stats,
    motif_order = order,
    null_motif_order = random_order,
    automorphism_count = automorphism_count_value,
    empirical.p = empirical_p,
    min_p_value = 1/(K + 1)
  )
  class(result) <- "motif.test.calibration"
  result
}
print.motif.test.calibration <- function(x, ...){
  cat("Random-network motif calibration\n")
  cat("  null model:       ", x$null_model, "\n", sep = "")
  cat("  statistic:        ", x$statistic, "\n", sep = "")
  cat("  alternative:      ", x$alternative, "\n", sep = "")
  cat("  random networks:  ", x$K, "\n", sep = "")
  cat("  motif order:      ", paste(x$motif_order, collapse = " -> "), "\n", sep = "")
  if(!is.null(x$null_motif_order) && !identical(x$null_motif_order, x$motif_order)){
    cat("  null motif order: ", paste(x$null_motif_order, collapse = " -> "), "\n", sep = "")
  }
  cat("  min p-value:      ", signif(x$min_p_value, 4), "\n", sep = "")
  cat("  observed count:   ", signif(x$observed_count, 6),
      " (SE ", signif(x$observed_count_se, 4), ")\n", sep = "")
  cat("  null expectation: ", signif(x$null_expectation, 6), "\n", sep = "")
  cat("\nCalibration table\n")
  print(x$calibration_table, row.names = FALSE)
  invisible(x)
}
summary.motif.test.calibration <- function(object, ...){
  object$calibration_table
}
motif.order.sensitivity <- function(G, H, B_observed = 10000, R_null = 10000,
                                    directed = FALSE,
                                    null_model = c("chung_lu", "erdos_renyi", "given"),
                                    P_null = NULL,
                                    null_variance = c("poisson", "none", "provided"),
                                    tau2_null = NULL,
                                    alternative = c("greater", "less", "two.sided"),
                                    seed = NULL,
                                    order = NULL,
                                    orders = c("observed", "null_density", "reverse"),
                                    random_orders = 0,
                                    vary = c("null", "both"),
                                    automorphism_count_value = NULL,
                                    verbose = FALSE,
                                    bootstrap_ci = FALSE,
                                    bootstrap_B = 1000){
  null_model <- match.arg(null_model)
  null_variance <- match.arg(null_variance)
  alternative <- match.arg(alternative)
  vary <- match.arg(vary)
  if(!is.null(seed)){set.seed(seed)}
  G <- norm.graph(G, directed = directed)
  H <- norm.graph(H, directed = directed)
  if(is.null(order)){
    order <- mot.order(H, g.dens(G, directed = directed), directed = directed)
  }else{
    order <- validate.motif.order(order, H, name = "order")
  }
  if(is.null(automorphism_count_value)){
    automorphism_count_value <- aut.morph(H, directed = directed)
  }
  P <- if(null_model == "given"){
    if(is.null(P_null)){stop("P_null must be supplied when null_model = 'given'.")}
    norm.probmat(P_null, directed = directed)
  }else{
    make.null(G, method = null_model, directed = directed)
  }
  order_list <- list()
  add_order <- function(name, value){
    value <- validate.motif.order(value, H, name = name)
    order_list[[name]] <<- value
    invisible(NULL)
  }
  if(length(orders) > 0){
    for(spec in orders){
      if(spec == "observed"){
        add_order("observed", order)
      }else if(spec == "null_density"){
        add_order("null_density", resolve.null.order(
          order_null = "null_density", H = H, P = P,
          observed_order = order, directed = directed
        ))
      }else if(spec == "reverse"){
        add_order("reverse", rev(order))
      }else{
        stop("Unknown order sensitivity option: ", spec)
      }
    }
  }
  if(random_orders > 0){
    for(i in seq_len(random_orders)){
      add_order(paste0("random_", i), sample(seq_len(nrow(H))))
    }
  }
  if(length(order_list) == 0){stop("No valid orders were supplied.")}
  results <- vector("list", length(order_list))
  names(results) <- names(order_list)
  table <- vector("list", length(order_list))
  i <- 0L
  for(name in names(order_list)){
    i <- i + 1L
    candidate_order <- order_list[[name]]
    observed_order <- if(vary == "both"){candidate_order}else{order}
    null_order <- candidate_order
    res <- motif.test(
      G = G,
      H = H,
      B_observed = B_observed,
      R_null = R_null,
      directed = directed,
      null_model = null_model,
      P_null = P_null,
      null_variance = null_variance,
      tau2_null = tau2_null,
      alternative = alternative,
      seed = if(is.null(seed)) NULL else seed + 100L * i,
      order = observed_order,
      order_null = null_order,
      automorphism_count_value = automorphism_count_value,
      verbose = verbose,
      bootstrap_ci = bootstrap_ci,
      bootstrap_B = bootstrap_B,
      bootstrap_seed = if(is.null(seed)) NULL else seed + 10000L + 100L * i
    )
    results[[name]] <- res
    table[[i]] <- data.frame(
      order_name = name,
      varied_component = vary,
      observed_order = paste(res$motif_order, collapse = " -> "),
      null_order = paste(res$null_motif_order, collapse = " -> "),
      observed_count = res$estimates$observed_count,
      observed_se = res$estimates$observed_se,
      null_expectation = res$estimates$null_expectation,
      null_expectation_se = res$estimates$null_expectation_se,
      log_enrichment = res$estimates$log_enrichment,
      log_enrichment_se_total = res$estimates$log_enrichment_se_total,
      p.value = res$coefficient_table$p.value[1],
      observed_ess_ratio = res$observed$weight_diagnostics$ess_ratio,
      null_ess_ratio = res$null_expectation$weight_diagnostics$ess_ratio,
      observed_max_weight_share = res$observed$weight_diagnostics$max_weight_share,
      null_max_weight_share = res$null_expectation$weight_diagnostics$max_weight_share,
      row.names = NULL
    )
  }
  out <- list(
    call = match.call(),
    sensitivity_table = do.call(rbind, table),
    results = results,
    vary = vary,
    null_model = null_model,
    B_observed = B_observed,
    R_null = R_null,
    random_orders = random_orders
  )
  class(out) <- "motif.order.sensitivity"
  out
}
print.motif.order.sensitivity <- function(x, ...){
  cat("Motif order sensitivity analysis\n")
  cat("  varied component: ", x$vary, "\n", sep = "")
  cat("  null model:       ", x$null_model, "\n", sep = "")
  cat("  B observed:       ", x$B_observed, "\n", sep = "")
  cat("  R null:           ", x$R_null, "\n", sep = "")
  cat("\nSensitivity table\n")
  print(x$sensitivity_table, row.names = FALSE)
  invisible(x)
}
#==========================================================================
